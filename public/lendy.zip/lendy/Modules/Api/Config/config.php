<?php

return [
    'name' => 'Api',
    'passport' => [
        'client_id' => env('PASSPORT_CLIENT_ID','2'),
        'client_secret' => env('PASSPORT_CLIENT_SECRET','PwncSpeOCLn7Q9lbBb3WadGSB1hv65M3M8H80iHH'),
    ],
];
