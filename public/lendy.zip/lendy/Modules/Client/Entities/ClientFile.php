<?php

namespace Modules\Client\Entities;

use Illuminate\Database\Eloquent\Model;

class ClientFile extends Model
{
    protected $table = 'client_files';
    protected $fillable = [];


}
