<?php

namespace Modules\Core\Entities;

use Illuminate\Database\Eloquent\Model;

class TaxRate extends Model
{
    protected $fillable = [];
    public $table = 'tax_rates';
}
