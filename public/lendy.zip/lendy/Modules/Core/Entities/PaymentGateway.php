<?php

namespace Modules\Core\Entities;

use Illuminate\Database\Eloquent\Model;

class PaymentGateway extends Model
{
    protected $fillable = [];
}
