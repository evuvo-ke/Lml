<?php

namespace Modules\Core\Entities;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    protected $table = "currencies";
    protected $fillable = [];
}
