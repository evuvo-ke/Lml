<?php

namespace Modules\Core\Entities;

use Illuminate\Database\Eloquent\Model;

class PaymentType extends Model
{
    protected $table = "payment_types";
    protected $fillable = [];
}
