<?php

namespace Modules\Asset\Entities;

use Illuminate\Database\Eloquent\Model;

class AssetPicture extends Model
{
    protected $fillable = [];
    protected $table = 'asset_pictures';
}
