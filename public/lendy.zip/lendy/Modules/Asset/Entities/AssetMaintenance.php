<?php

namespace Modules\Asset\Entities;

use Illuminate\Database\Eloquent\Model;

class AssetMaintenance extends Model
{
    protected $fillable = [];
    protected $table = 'asset_maintenance';
}
