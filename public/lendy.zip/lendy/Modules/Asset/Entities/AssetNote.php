<?php

namespace Modules\Asset\Entities;

use Illuminate\Database\Eloquent\Model;

class AssetNote extends Model
{
    protected $fillable = [];
    protected $table = 'asset_notes';
}
