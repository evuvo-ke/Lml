<?php

namespace Modules\Asset\Entities;

use Illuminate\Database\Eloquent\Model;

class AssetFile extends Model
{
    protected $fillable = [];
    protected $table = 'asset_files';
}
