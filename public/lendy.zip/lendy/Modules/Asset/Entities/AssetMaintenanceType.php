<?php

namespace Modules\Asset\Entities;

use Illuminate\Database\Eloquent\Model;

class AssetMaintenanceType extends Model
{
    protected $fillable = [];
    protected $table = 'asset_maintenance_types';
}
