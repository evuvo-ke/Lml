<?php

return [
    'name' => 'Asset'
];
