<?php
if (!function_exists('record_accounting_record')) {
    function record_accounting_record($amount, $debit, $credit, $transaction_type)
    {

    }
}