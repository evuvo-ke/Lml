<?php

return [
    'name' => 'Accounting'
];
