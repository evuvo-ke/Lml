@component('mail::message')
    {!! $body !!}
@endcomponent
