<?php
/**
 * Created by PhpStorm.
 * User: tj
 * Date: 7/28/19
 * Time: 2:52 PM
 */
return [
    'communication' => 'Communication',
    'sms' => 'SMS|SMSs',
    'email' => 'Email|Emails',
    'gateway' => 'Gateway|Gateways',
    'campaign' => 'Campaign|Campaigns',
    'to_name' => 'To Name',
    'msg_name' => 'Msg Name',
    'url' => 'URL',
    'triggered' => 'Triggered',
    'schedule' => 'Schedule',
    'direct' => 'Direct',
    'business_rule' => 'Business Rule|Business Rules',
    'attachment' => 'Attachment|Attachments',
    'report' => 'Report|Reports',
    'from_x' => 'From X',
    'to_y' => 'To Y',
    'cycle_x' => 'Cycle X',
    'cycle_y' => 'Cycle Y',
    'overdue_x' => 'Overdue X',
    'overdue_y' => 'Overdue Y',
    'trigger' => 'Trigger|Triggers',
    'log' => 'Log|Logs',
    'delivered'=>'Delivered',
    'sent'=>'Sent',
    'failed'=>'Failed',
    'send_to'=>'Send To',
    'subject'=>'Subject|Subjects',
    'active'=>'Active',
    'inactive'=>'Inactive',
    'closed'=>'Closed',
    'pending'=>'Pending',
    'done'=>'Done',

];