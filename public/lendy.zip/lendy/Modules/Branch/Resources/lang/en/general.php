<?php
/**
 * Created by PhpStorm.
 * User: tj
 * Date: 7/6/19
 * Time: 12:20 PM
 */
return [
    'user_already_added_to_branch' => 'User already added to branch',
    'open'=>'Open',
    'branch'=>'Branch|Branches',
];
