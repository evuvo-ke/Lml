<?php
return [
    ['name' => 'branch.branches.index', 'display_name' => 'View Branches', 'module' => 'Branch'],
    ['name' => 'branch.branches.create', 'display_name' => 'Create Branches', 'module' => 'Branch'],
    ['name' => 'branch.branches.edit', 'display_name' => 'Edit Branches', 'module' => 'Branch'],
    ['name' => 'branch.branches.destroy', 'display_name' => 'Delete Branches', 'module' => 'Branch'],
    ['name' => 'branch.branches.assign_user', 'display_name' => 'Assign Users', 'module' => 'Branch'],
];