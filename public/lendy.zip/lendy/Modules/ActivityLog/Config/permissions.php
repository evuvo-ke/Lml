<?php
return [
    ['name' => 'activitylog.activity_logs.index', 'display_name' => 'View Activity Logs', 'module' => 'Activitylog'],
    ['name' => 'activitylog.activity_logs.destroy', 'display_name' => 'Delete Activity Logs', 'module' => 'Activitylog'],
];